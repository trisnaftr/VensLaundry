<h2>Beranda</h2><hr color="#0263A0">
<br>
<p>Welcome to VEN's Laundry Online</p>
