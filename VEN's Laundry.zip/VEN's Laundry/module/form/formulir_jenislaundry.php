<h2>Form Pendaftaran Jenis Laundry</h2>
<hr color="#0263A0"><br>

<form action="../process/input/input_jenislaundry.php" method="POST">

    <table>
        <tr>
            <td>ID Jenis Laundry</td>
        </tr>
        <tr>
            <td><input type="text" name='IDJenisLaundry' size="25px" maxlength="5" placeholder="ketikkan ID jenis laundry.."></td>
        </tr>

        <tr>
            <td>Nama Jenis Laundry</td>
        </tr>
        <tr>
            <td><input type="text" name="NmJenisLaundry" size="25px" maxlength="20" placeholder="ketikkan nama jenis laundry.."></td>
        </tr>

        <tr>
            <td><br><input class="tombol" type="submit" value="Tambah"></td>
        </tr>

    </table>

</form>